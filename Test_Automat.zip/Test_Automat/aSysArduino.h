// Created 19.06.2023 22:13:16

#ifndef FSA_aSysArduino_H
#define FSA_aSysArduino_H

typedef struct  {
  volatile uint32_t uNewState;
  volatile uint32_t uOldState;
  volatile uint32_t uOld1State;
  volatile uint32_t uOld2State;
  volatile uint32_t uOld3State;
  volatile uint32_t uOld4State;
  volatile uint32_t uOld5State;
  volatile uint32_t uIsOldReturn; // Flag Return old
  volatile uint32_t uCallState;
  volatile uint32_t uCall1State;
  volatile uint32_t uCall2State;
  volatile uint32_t uCall3State;
  volatile uint32_t uCall4State;
  volatile uint32_t uCall5State;
  volatile uint32_t uIsCallReturn; // Flag Return Call
  volatile int32_t iCounter; 
  volatile uint32_t uTimer0; // TIMER 
  volatile uint32_t uTimer; 
  volatile uint32_t uClock; 
  volatile uint32_t uCurState;

} SW_aSysArduino_t;

extern SW_aSysArduino_t SW_aSensor; //Тестовый автомат

extern uint32_t uSW_aSensor_Wait_Time[]; // Wait time
void set_SW_aSensor_Wait(uint32_t uNumWait, uint32_t uTim_Wait); // Set time for wait
uint32_t is_SW_aSensor_Wait(uint32_t uNumWait); // is time for wait clear

void return_old_aSensor(void); // Return old
void return_Call_aSensor(void); // Return Call
void aSensor_Call (void); // Return Call

void aSensor(void); //  for run one aSensor if need (parexamle in systick)

void aSysArduino(void); // Run All automate aSysArduino

void aSysArduino_init(void); //Init All automate aSysArduino

void aSysArduino_Systick(void); // For run all Wait in Systick
void aSysArduino__Mills(void); // For run Step Timers
#endif
